- Delta Rule

The implementation of delta rule described in https://arxiv.org/abs/2102.11174 

