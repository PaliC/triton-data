wget https://people.eecs.berkeley.edu/~hendrycks/data.tar
tar xf data.tar