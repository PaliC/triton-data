set -e
python test0.py
python test1.py
python test2.py
python test3.py
python test4.py
python test5.py
python test6.py
