make clean
make html
python -m http.server -d build/html/ 5888