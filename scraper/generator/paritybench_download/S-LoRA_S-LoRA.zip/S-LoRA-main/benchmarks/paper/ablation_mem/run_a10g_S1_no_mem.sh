python ../run_exp.py  --backend slora  --suite ablation-no-mem  --model-setting S1  --mode synthetic  --output ablation_mem_a10g_S1_no_mem.jsonl
