python ../launch_server.py  --device a10g  --model-setting S1  --backend slora  --num-adapter 200  --num-token 15000 --no-mem-pool
