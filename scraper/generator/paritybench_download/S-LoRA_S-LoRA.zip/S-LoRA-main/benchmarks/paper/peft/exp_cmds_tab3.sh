# python ../../run_exp_peft.py --model-setting S1 --suite a10g --breakdown --output num_adapter_a10g_S1_peft.jsonl --append
# python ../../run_exp_peft.py --model-setting S1 --suite a100-80-num-adapter-s12-peft --output num_adapter_a100-80_S1_peft_fig3.jsonl
# python ../../run_exp_peft.py --model-setting S2 --suite a100-80-num-adapter-s12-peft --output num_adapter_a100-80_S2_peft_fig3.jsonl
python ../../run_exp_peft.py --model-setting S4 --suite a100-80-num-adapter-s4-peft --output num_adapter_a100-80_S4_peft_fig3.jsonl


