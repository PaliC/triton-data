Fused Softmax in Triton, supporting both inference (fwd) and training (fwd/backward). 

Perf testing on A100:

<img width="790" alt="fused_softmax_a100" src="https://github.com/lessw2020/applied-ai/assets/46302957/c8930c44-9960-4353-83be-e8f6e4b24d96">
