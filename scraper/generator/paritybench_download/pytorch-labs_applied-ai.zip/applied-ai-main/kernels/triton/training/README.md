Triton training kernels
