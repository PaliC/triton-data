Triton tutorials
