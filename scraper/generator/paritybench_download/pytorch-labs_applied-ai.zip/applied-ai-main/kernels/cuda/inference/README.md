cuda kernels
