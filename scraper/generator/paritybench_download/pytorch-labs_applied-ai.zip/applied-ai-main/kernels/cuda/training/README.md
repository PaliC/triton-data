kernels with backward pass support
