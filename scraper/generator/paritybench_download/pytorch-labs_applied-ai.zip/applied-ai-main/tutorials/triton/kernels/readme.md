Triton tutorials

1 - Vector Add - Starting tutorial on simple first kernel  
2 - Fused Softmax - Full fused softmax with both forward and backward (training ready)
