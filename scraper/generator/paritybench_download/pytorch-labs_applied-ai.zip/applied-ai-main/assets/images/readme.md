Folder for housing images for the readmes.
