Download dataset from https://github.com/deepmind/pg19 in this folder. The run prepare.py
