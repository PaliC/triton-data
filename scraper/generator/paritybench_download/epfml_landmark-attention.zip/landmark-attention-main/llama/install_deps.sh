#!/bin/bash

pip install -r requirements.txt
pip install "git+https://github.com/openai/triton.git#subdirectory=python"
