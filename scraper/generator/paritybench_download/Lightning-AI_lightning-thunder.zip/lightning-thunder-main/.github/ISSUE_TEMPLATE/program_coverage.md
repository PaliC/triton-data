---
name: Program Coverage
about: Expand the programs / models Thunder can process
title: ''
labels: program-coverage
assignees: ''
---

## 🚀 Model / language coverage

<!-- A clear and concise description of the code construct you want to support -->

### Pitch

<!-- A clear and concise description of the impact (what models are enabled etc.) to help us prioritize coverage. -->

### Alternatives / Potential work-arounds

<!-- If you have thoughts on working around the issue or alternative functionality to achieve your goal, we would be keen to hear them.  >

### Minimal Repro

<!-- A minimal reproduction to demonstrate the current error message. -->
