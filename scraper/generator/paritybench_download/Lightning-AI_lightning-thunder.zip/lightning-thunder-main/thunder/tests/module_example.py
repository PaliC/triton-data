def returns_two():
    return 2


def _returns_three():
    return 3


def returns_five():
    return 5
