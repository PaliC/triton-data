.. module:: thunder.core.functionalization

In-place Functionalization
--------------------------

.. currentmodule:: thunder.core.functionalization

.. autosummary::
    :toctree: generated/

    functionalize_inplace_ops
