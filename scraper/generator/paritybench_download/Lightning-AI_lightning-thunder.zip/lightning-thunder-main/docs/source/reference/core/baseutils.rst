.. module:: thunder.core.baseutils
    :noindex:

Baseutils
---------

.. currentmodule:: thunder.core.baseutils

.. autosummary::
    :toctree: generated/

    check
    check_type
    ProxyInterface
    NumberProxyInterface
    TensorProxyInterface
    SymbolInterface
    BoundSymbolInterface
