.. module:: thunder.core.prims

.. todo Add other prims after resolving "Cannot resolve forward reference in type annotations of "thunder.core.prims.all_reduce": name 'Callable' is not defined"

Prims
-----

.. currentmodule:: thunder.core.prims

.. autosummary::
    :toctree: generated/

    PrimIDs
