.. module:: thunder.executors.nvfuserex

nvFuser Executor
----------------

An executor dispatches operators to `NVIDIA/Fuser <https://github.com/nvidia/fuser>`_.

.. currentmodule:: thunder.executors.nvfuserex

.. autosummary::
    :toctree: generated/

.. fixme(crcrpar) add methods and classes
