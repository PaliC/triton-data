.. module:: thunder.executors.torchex


PyTorch Executor
----------------

.. currentmodule:: thunder.executors.torch_autograd

.. autosummary::
    :toctree: generated/
