.. module:: thunder.core.codeutils

Codeutils
---------

.. currentmodule:: thunder.core.codeutils

.. autosummary::
    :toctree: generated/

    prettyprint
    SigInfo
    get_siginfo
