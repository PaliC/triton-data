.. module:: thunder.executors.pythonex


Python Executor
---------------

.. currentmodule:: thunder.executors.pythonex

.. autosummary::
    :toctree: generated/
