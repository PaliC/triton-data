.. module:: thunder.executors.torch_compile

Torch Compile Executor
----------------------

.. currentmodule:: thunder.executors.torch_compile

.. autosummary::
    :toctree: generated/

    to_torch_translator
    make_compiled
    TorchCompileExecutor
