.. module:: thunder.torch

thunder.torch
-------------

A PyTorch dialect in thunder.

.. currentmodule:: thunder.torch

.. autosummary::
    :toctree: generated/

    torchsymbol
    size
    to_float

Under Construction

.. fixme "Cannot resolve forward reference in type annotations of "thunder.torch.abs": name 'Callable' is not defined"

Operators
~~~~~~~~~

Unary
~~~~~

Binary
~~~~~~

Conditional
~~~~~~~~~~~

Tensor Creation
~~~~~~~~~~~~~~~

Shape Operation
~~~~~~~~~~~~~~~
