.. module:: thunder.core.langctxs

langctxs
--------

.. currentmodule:: thunder.core.langctxs

.. autosummary::
    :toctree: generated/

    set_langctx
    get_langctx
    reset_langctx
    langctx
