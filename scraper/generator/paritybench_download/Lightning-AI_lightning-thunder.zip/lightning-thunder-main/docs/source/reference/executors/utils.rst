.. module:: thunder.executors.utils

Utils
-----

.. currentmodule:: thunder.executors.utils

.. autosummary::
    :toctree: generated/

    Region
