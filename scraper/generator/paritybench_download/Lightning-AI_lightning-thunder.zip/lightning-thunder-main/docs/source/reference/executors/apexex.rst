.. module:: thunder.executors.apexex

APEX Executor
-------------

Executor of `NVIDIA/apex <https://github.com/nvidia/apex>`_.

.. currentmodule:: thunder.executors.apexex

.. autosummary::
    :toctree: generated/

    apex_entropy_available
