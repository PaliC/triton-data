.. module:: thunder.executors.triton_crossentropy

Triton Executor
---------------

Executor of `openai/triton <https://github.com/openai/triton>`_.

.. currentmodule:: thunder.executors.triton_crossentropy

.. autosummary::
    :toctree: generated/
