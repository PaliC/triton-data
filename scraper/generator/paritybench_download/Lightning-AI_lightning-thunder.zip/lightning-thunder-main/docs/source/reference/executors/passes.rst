.. module:: thunder.executors.passes

Optimization Passes
-------------------

.. currentmodule:: thunder.executors.passes

.. autosummary::
    :toctree: generated/

    transform_for_execution
    update_fusion_call_ctx
    del_last_used
