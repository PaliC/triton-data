.. module:: thunder.core.devices

Devices
-------

.. currentmodule:: thunder.core.devices

.. autosummary::
    :toctree: generated/

    DeviceType
    devicetype_string
    Device
    device_from_string
    to_device
