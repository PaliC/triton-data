This has been tested with

https://github.com/Stability-AI/generative-models/tree/9d759324e914de6c96dbd1468b3a4a50243c6528/

and Python 3.10 and 3.11 should run through the Thunder Python JIT correctly on rtx3090+ if you install the dependencies (but be sure to use gpu-enabled xformers).
